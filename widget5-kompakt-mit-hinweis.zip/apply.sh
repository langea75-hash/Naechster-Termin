#!/usr/bin/env bash
set -e

echo "Neue kompakte Widget-Version wird übernommen ..."

git add   app/src/main/res/layout/widget_next_event.xml   app/src/main/java/de/andreas/naechstertermin/NextEventWidgetProvider.java

git commit -m "Widget kompakt ohne Ueberschrift mit Hinweis" || true
git push

echo "FERTIG"
