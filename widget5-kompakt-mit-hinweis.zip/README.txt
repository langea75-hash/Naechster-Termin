WIDGET 5 – KOMPAKT MIT HINWEIS

NEU:
- „Nächster Termin“ entfernt
- Kalenderkästchen entfernt
- kleinere Schrift
- Termintitel bis 2 Zeilen
- Datum + Start- und Endzeit
- Live-Countdown
- Ort bis 2 Zeilen
- Hinweis/Beschreibung aus Google Kalender bis 3 Zeilen

IM CODESPACE:
1. unzip -o widget5-kompakt-mit-hinweis.zip
2. bash apply.sh

Danach in GitHub:
Actions -> Android APK -> neuen erfolgreichen Build öffnen -> Artifact herunterladen.
