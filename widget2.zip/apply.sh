#!/usr/bin/env bash
set -e

git add app/src/main/res/layout/widget_next_event.xml         app/src/main/res/drawable/widget_background.xml         app/src/main/res/drawable/calendar_badge_background.xml         app/src/main/res/drawable/calendar_month_background.xml         app/src/main/res/drawable/countdown_background.xml         app/src/main/res/xml/next_event_widget_info.xml         app/src/main/java/de/andreas/naechstertermin/NextEventWidgetProvider.java

git commit -m "Widget kompakter und schoener" || true
git push
echo "FERTIG"
