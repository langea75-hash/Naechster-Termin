NÄCHSTER TERMIN – ANDROID WIDGET 2.0

Neue schönere Version:
- dynamischer Kalender-Kasten: AUG / 26 statt festem Emoji „July 17“
- runde helle Widget-Karte
- bessere Typografie und Abstände
- Countdown in eigener Fläche
- kompakter Ort
- auch die App selbst ist aufgeräumter

Installation über GitHub:
1. Projektdateien in dein bestehendes Repository übernehmen.
2. Commit + Push.
3. GitHub Actions baut automatisch eine neue app-debug.apk.
4. APK installieren. Die bestehende App wird aktualisiert.
5. Widget ggf. entfernen und neu auf den Startbildschirm setzen.
