function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Nächster Termin')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function getNextEvent() {
  const now = new Date();
  const end = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  const calendar = CalendarApp.getDefaultCalendar();

  const events = calendar.getEvents(now, end)
    .filter(event => event.getEndTime() > now)
    .sort((a, b) => a.getStartTime() - b.getStartTime());

  if (events.length === 0) {
    return { found: false };
  }

  const e = events[0];
  const allDay = e.isAllDayEvent();

  return {
    found: true,
    title: e.getTitle() || 'Termin',
    start: e.getStartTime().toISOString(),
    end: e.getEndTime().toISOString(),
    allDay: allDay,
    location: e.getLocation() || '',
    description: e.getDescription() || ''
  };
}
